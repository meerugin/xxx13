﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPersonalClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Person employee = new Person();

            employee.FirstName = textBox1.Text;
            employee.LastName = textBox2.Text;

            DateTime dob = dateTimePicker1.Value;

            int age = employee.GetAge(dob);

            MessageBox.Show($"Имя: {employee.FirstName}\n" +
                            $"Фамилия: {employee.LastName}\n" +
                            $"Возраст: {age} лет");
        }
    }
}
