﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPersonalClass
{
    public class Person
    {
        private string firstName;
        private string lastName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public int GetAge(DateTime birthday)
        {
            DateTime currentDate = DateTime.Now;
            TimeSpan difference = currentDate - birthday;
            return (int)(difference.TotalDays / 365.25);
        }
    }
}
